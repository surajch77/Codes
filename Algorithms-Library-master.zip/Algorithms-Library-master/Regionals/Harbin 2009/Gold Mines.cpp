#include <stdio.h>

using namespace std;

int main(){
    long long i = 0LL, st = 1000000000000LL;
    for (;true;i++){
        if (i>=st)
            break;
    }
}
