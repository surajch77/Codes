Algorithms-Library
==================

This is just my implementation to some algorithms and data structures in both Java and C++.
