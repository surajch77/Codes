#include<stdio.h>
#include<string.h>
#include<queue>

using namespace std;

char grid[201][201];
int vis [1000][1000];
