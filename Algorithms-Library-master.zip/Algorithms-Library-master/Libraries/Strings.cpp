#include<stdio.h>
#include<string.h>
#include<string>

using namespace std;

const int MAXN = 10000000;

string pattern, text;

int fail[MAXN];

void fail_fn(){
    for (int i=0;i<pattern.size();i++)
}
